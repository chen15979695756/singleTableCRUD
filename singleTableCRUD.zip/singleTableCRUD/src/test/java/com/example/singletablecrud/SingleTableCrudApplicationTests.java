package com.example.singletablecrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SingleTableCrudApplicationTests {

    @Test
    void contextLoads() {
    }

}
