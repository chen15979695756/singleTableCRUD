package com.example.singletablecrud.service;

import com.example.singletablecrud.entity.User;
import com.example.singletablecrud.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author chenyang
 * @create 2021/7/22 9:50
 */
@Service
public class UserService {
    @Autowired
    private UserMapper userMapper;
    public User getUserInfo(int id) {
        return userMapper.getUserInfo(id);
    }


    public int deleteById(int id) {
        return userMapper.deleteById(id);
    }

    public int Update(User user) {
        return userMapper.update(user);
    }

    public int  save(User user) {
        int cols=userMapper.save(user);//受影响的行数
        return cols;
    }

    public List<User> selectAll() {
        return userMapper.selectAll();

    }

}
