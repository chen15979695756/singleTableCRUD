package com.example.singletablecrud.mapper;

import com.example.singletablecrud.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author chenyang
 * @create 2021/7/22 10:11
 */
@Mapper
public interface UserMapper {

        /**
         * 根据id查询用户信息
         *
         * @param id
         * @return
         */
        User getUserInfo(int id) ;


        /**
         * 新增用户
         *
         * @param user
         * @return
         */
        int save(User user) ;


        /**
         * 更新用户信息
         *
         * @param user
         * @return
         */
        int update(User user) ;


        /**
         * 根据id删除
         *
         * @param id
         * @return
         */
        int deleteById(int id) ;


        /**
         * 查询所有用户信息
         *
         * @return
         */
        List<User> selectAll() ;
}
