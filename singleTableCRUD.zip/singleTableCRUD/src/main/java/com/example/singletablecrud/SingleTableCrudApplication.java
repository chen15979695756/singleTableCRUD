package com.example.singletablecrud;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@MapperScan("com.example.singletablecrud.mapper") //扫描的mapper
@SpringBootApplication
public class SingleTableCrudApplication {

    public static void main(String[] args) {
        SpringApplication.run(SingleTableCrudApplication.class, args);
    }

}
